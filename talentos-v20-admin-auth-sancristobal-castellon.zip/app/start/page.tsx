"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { TALENTS } from "@/lib/talents";
import TalentWheel from "@/components/TalentWheel";
import { SANCRISTOBAL_BRANDING, SANCRISTOBAL_CENTER } from "@/lib/branding";
import { usePathname } from "next/navigation";

type PreData = {
  nombre: string;
  email: string;
};

type PostData = {
  apellido: string;
  fechaNacimiento: string;
  genero: "Femenino" | "Masculino" | "";
  curso: string;
  modalidad: string;
  centroEducativo: string;
  ideaCarreraFinal: "Sí" | "No" | "";
  ideaCarreraTextoFinal: string;
  identificaCampos: "Sí" | "No" | "";
  campoIdentificado: string;
};

type Answers = Record<string, number>;

type Question = {
  itemId: string;
  text: string;
  talentId: number;
  talentCode: string;
  talentQuizTitle: string;
};

const initialPre: PreData = {
  nombre: "",
  email: "",
};

const initialPost: PostData = {
  apellido: "",
  fechaNacimiento: "",
  genero: "",
  curso: "",
  modalidad: "",
  centroEducativo: "",
  ideaCarreraFinal: "",
  ideaCarreraTextoFinal: "",
  identificaCampos: "",
  campoIdentificado: "",
};

const STEM = "ME GUSTAN LAS ACTIVIDADES O PIENSO EN UNA PROFESIÓN DONDE...";

function handleBrandLogoError(event: React.SyntheticEvent<HTMLImageElement, Event>) {
  const img = event.currentTarget;
  if (img.dataset.logoFallbackApplied === "true") return;
  img.dataset.logoFallbackApplied = "true";
  img.src = "/sancristobal-logo.png";
}

function normalizeItemText(s: any): string {
  if (typeof s !== "string") return "";
  const t = s.trim();
  if (!t) return "";
  return t.replace(/\s+/g, " ");
}

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

function safeNum(value: any): string {
  if (typeof value === "number" && !isNaN(value)) return String(value);
  if (typeof value === "string") return value;
  return "0";
}

function ProgressRing({ value }: { value: number }) {
  const pct = clamp(Math.round(value), 0, 100);
  const style = {
    background: `conic-gradient(var(--foreground) ${pct}, rgba(148,163,184,0.35) ${pct} 100%)`,
  } as React.CSSProperties;

  return (
    <div className="flex items-center gap-3">
      <div className="w-11 h-11 rounded-full p-[3px]" style={style}>
        <div className="w-full h-full rounded-full bg-[var(--card)] flex items-center justify-center border border-[var(--border)]">
          <span className="text-[11px] font-semibold text-[var(--foreground)]">{pct}</span>
        </div>
      </div>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-sm text-[var(--muted-foreground)]">{children}</label>;
}

function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cx(
        "mt-2 w-full rounded-2xl border border-[var(--border)] bg-[var(--card)] px-4 py-3",
        "text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] shadow-sm",
        "focus:outline-none focus:ring-2 focus:ring-[var(--ring)] transition disabled:opacity-60",
        props.className
      )}
    />
  );
}

function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cx(
        "mt-2 w-full rounded-2xl border border-[var(--border)] bg-[var(--card)] px-4 py-3",
        "text-[var(--foreground)] shadow-sm",
        "focus:outline-none focus:ring-2 focus:ring-[var(--ring)] transition disabled:opacity-60",
        props.className
      )}
    />
  );
}

function ButtonPrimary(props: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={cx(
        "px-4 py-2.5 rounded-2xl text-sm font-semibold",
        "bg-[var(--accent)] text-[var(--accent-foreground)]",
        "shadow-[0_10px_25px_-15px_rgba(0,0,0,0.35)]",
        "hover:opacity-95 hover:-translate-y-[1px] active:translate-y-0 transition",
        "disabled:opacity-50 disabled:hover:translate-y-0",
        props.className
      )}
    />
  );
}

function ButtonGhost(props: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={cx(
        "px-4 py-2.5 rounded-2xl text-sm font-semibold",
        "border border-[var(--border)] bg-[var(--card)] text-[var(--foreground)]",
        "shadow-sm hover:-translate-y-[1px] active:translate-y-0 transition",
        "disabled:opacity-50 disabled:hover:translate-y-0",
        props.className
      )}
    />
  );
}

const SCALE = [
  { n: 0, label: "Nada" },
  { n: 1, label: "Un poco" },
  { n: 2, label: "Bastante" },
  { n: 3, label: "Totalmente" },
] as const;

export default function StartPage() {
  const questions = useMemo<Question[]>(() => {
    const allQuestions = TALENTS.flatMap((t) =>
      t.items.map((it) => ({
        itemId: it.id,
        text: it.text,
        talentId: t.id,
        talentCode: t.code,
        talentQuizTitle: t.quizTitle,
      }))
    );

    return shuffle(allQuestions);
  }, []);

  const N = questions.length;
  const STEP_PRE = 1;
  const STEP_Q_START = 2;
  const STEP_Q_END = STEP_Q_START + N - 1;
  const STEP_RESULT = STEP_Q_END + 1;
  const STEP_POST_1 = STEP_RESULT + 1;
  const STEP_POST_2 = STEP_POST_1 + 1;
  const STEP_POST_3 = STEP_POST_2 + 1;
  const STEP_DONE = STEP_POST_3 + 1;

  const totalSteps = STEP_DONE;

  const [step, setStep] = useState<number>(STEP_PRE);
  const [pre, setPre] = useState<PreData>(initialPre);
  const [post, setPost] = useState<PostData>(initialPost);
  const [answers, setAnswers] = useState<Answers>({});
  const [error, setError] = useState<string>("");
  const [saving, setSaving] = useState<boolean>(false);
  const [savedOk, setSavedOk] = useState<boolean>(false);
  const [selectedCareers, setSelectedCareers] = useState<string[]>([]);
  const [otroCareerText, setOtroCareerText] = useState<string>("");

  const pathname = usePathname();
  const isSanCristobal = pathname?.startsWith("/sancristobal");
  const branding = isSanCristobal ? SANCRISTOBAL_BRANDING : null;

  useEffect(() => {
    if (!isSanCristobal) return;
    setPost((prev) =>
      prev.centroEducativo === SANCRISTOBAL_CENTER
        ? prev
        : { ...prev, centroEducativo: SANCRISTOBAL_CENTER }
    );
  }, [isSanCristobal]);

  const submittingRef = useRef(false);

  const isQuestionStep = step >= STEP_Q_START && step <= STEP_Q_END;
  const qIndex = isQuestionStep ? step - STEP_Q_START : -1;
  const currentQ = isQuestionStep && qIndex >= 0 && qIndex < questions.length ? questions[qIndex] : null;

  const progress = Math.round((step / totalSteps) * 100);

  function updatePre<K extends keyof PreData>(key: K, value: PreData[K]) {
    setPre((d) => ({ ...d, [key]: value }));
  }
  function updatePost<K extends keyof PostData>(key: K, value: PostData[K]) {
    setPost((d) => ({ ...d, [key]: value }));
  }
  function setAnswer(itemId: string, value: number) {
    setAnswers((a) => ({ ...a, [itemId]: value }));
  }

  function validateStep(): string {
    if (step === STEP_PRE) {
      if (!pre.nombre.trim()) return "Escribe tu nombre.";
      const email = pre.email.trim();
      if (!email) return "Escribe tu correo electrónico.";
      if (!isValidEmail(email)) return "Ese correo no parece válido.";
    }

    if (isQuestionStep && currentQ) {
      const v = answers[currentQ.itemId];
      if (v === undefined) return "Elige una opción para continuar.";
    }

    if (step === STEP_POST_1) {
      if (!post.apellido.trim()) return "Escribe tus apellidos.";
      if (!post.fechaNacimiento) return "Selecciona tu fecha de nacimiento.";
      if (Number.isNaN(new Date(post.fechaNacimiento).getTime())) return "La fecha no es válida.";
      if (!post.genero) return "Selecciona tu sexo.";
      if (!post.curso.trim()) return "Indica tu curso.";
      if (!post.modalidad.trim()) return "Indica tu modalidad.";
    }

    if (step === STEP_POST_2) {
      if (!post.ideaCarreraFinal) return "Indica si tienes una idea de carrera.";
      if (post.ideaCarreraFinal === "Sí" && post.ideaCarreraTextoFinal.trim().length < 2) {
        return "Escribe tu idea de carrera (aunque sea en pocas palabras).";
      }
    }

    if (step === STEP_POST_3) {
      if (selectedCareers.length === 0) {
        return "Selecciona al menos un campo profesional o marca 'Ninguna'.";
      }
      if (selectedCareers.includes("Otro") && !otroCareerText.trim()) {
        return "Escribe tu campo profesional personalizado en el campo 'Otro'.";
      }
    }

    return "";
  }

  function next() {
    const msg = validateStep();
    if (msg) return setError(msg);
    setError("");
    setStep((s) => clamp(s + 1, STEP_PRE, totalSteps));
  }

  function back() {
    setError("");
    setStep((s) => clamp(s - 1, STEP_PRE, totalSteps));
  }

  const scores = useMemo(() => {
    const scoreMap = new Map<number, number>();
    for (const q of questions) {
      const v = answers[q.itemId];
      if (v !== undefined) {
        scoreMap.set(q.talentId, (scoreMap.get(q.talentId) ?? 0) + v);
      }
    }
    return scoreMap;
  }, [questions, answers]);

  const ranked = useMemo(() => {
    return TALENTS.map((t) => ({
      id: t.id,
      code: t.code,
      quizTitle: t.quizTitle,
      titleSymbolic: t.titleSymbolic,
      titleGenotype: t.titleGenotype,
      reportTitle: t.reportTitle,
      reportSummary: t.reportSummary,
      exampleRoles: t.exampleRoles || [],
      score: scores.get(t.id) ?? 0,
      max: t.items.length * 3,
    })).sort((a, b) => b.score - a.score);
  }, [scores]);

  const winner = ranked[0];

  const wheelScores = useMemo(() => {
    return ranked.map((t) => ({
      talentId: t.id,
      score: t.score,
      max: t.max,
    }));
  }, [ranked]);

  function toggleCareer(career: string) {
    if (career === "Ninguna") {
      setSelectedCareers(["Ninguna"]);
    } else {
      setSelectedCareers((prev) => {
        const withoutNone = prev.filter(c => c !== "Ninguna");
        if (withoutNone.includes(career)) {
          return withoutNone.filter((c) => c !== career);
        } else {
          return [...withoutNone, career];
        }
      });
    }
  }

  async function saveAll() {
    const msg = validateStep();
    if (msg) return setError(msg);
    if (saving) return;

    for (const q of questions) {
      if (answers[q.itemId] === undefined) {
        setError("Faltan respuestas del cuestionario.");
        return;
      }
    }

    setSaving(true);
    setError("");

    try {
      const careersToSave = selectedCareers.map(c => c === "Otro" ? otroCareerText.trim() : c).filter(Boolean);
      const identificaCampos = careersToSave.length > 0 && !careersToSave.includes("Ninguna") ? "Sí" : "No";
      const campoIdentificado = careersToSave.includes("Ninguna") ? null : careersToSave.join(", ");

      const res = await fetch("/api/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre: pre.nombre.trim(),
          email: pre.email.trim(),
          apellido: post.apellido.trim(),
          fechaNacimiento: post.fechaNacimiento,
          genero: post.genero,
          curso: post.curso.trim(),
          modalidad: post.modalidad.trim(),
          centroEducativo: post.centroEducativo.trim() || null,
          tienesIdeaCarrera: post.ideaCarreraFinal || "No",
          ideaCarrera: post.ideaCarreraFinal === "Sí" ? post.ideaCarreraTextoFinal.trim() : null,
          ideaCarreraFinal: post.ideaCarreraFinal || null,
          ideaCarreraTextoFinal: post.ideaCarreraFinal === "Sí" ? post.ideaCarreraTextoFinal.trim() : null,
          identificaCampos,
          campoIdentificado,
          answers,
        }),
      });

      const json = await res.json().catch(() => ({} as any));

      if (!res.ok) {
        setError(json?.error ?? "No se pudo guardar.");
        setSaving(false);
        return;
      }

      setSavedOk(true);
      setSaving(false);
      setStep(STEP_DONE);
    } catch {
      setError("Error de red. Inténtalo de nuevo.");
      setSaving(false);
    }
  }


  if (step === STEP_RESULT) {
    return (
      <main className="min-h-screen bg-[var(--background)]">
        <div className="max-w-4xl mx-auto px-4 py-12">
          {branding ? (
            <div className="mb-6 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-4 shadow-sm">
              <img src={branding.logoSrc} alt={branding.name} className="h-20 w-auto object-contain" onError={handleBrandLogoError} />
            </div>
          ) : null}
          <header className="flex items-end justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-[var(--foreground)]">Tus Resultados</h1>
              <p className="mt-2 text-sm text-[var(--muted-foreground)]">Mapa visual de tus talentos</p>
            </div>
            <div className="flex items-center gap-3">
              <ProgressRing value={progress} />
            </div>
          </header>

          <div className="rounded-3xl border border-[var(--border)] bg-[var(--card)] p-6 shadow-sm mb-8">
            <TalentWheel scores={wheelScores} showFullLabels={true} minimal />
          </div>

          {error && (
            <div className="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
          )}

          <div className="mt-6 flex justify-end gap-3">
            <ButtonPrimary
              type="button"
              onClick={() => {
                setError("");
                setStep(STEP_POST_1);
              }}
            >
              Continuar con el registro
            </ButtonPrimary>
          </div>
        </div>
      </main>
    );
  }

  if (isQuestionStep && !currentQ) {
    return (
      <main className="min-h-screen bg-[var(--background)] flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg text-[var(--foreground)]">Error: No se pudo cargar la pregunta</p>
          <ButtonPrimary className="mt-4" onClick={back}>
            Volver
          </ButtonPrimary>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <div className="max-w-2xl mx-auto px-4 py-12">
        {branding ? (
          <div className="mb-6 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-4 shadow-sm">
            <img src={branding.logoSrc} alt={branding.name} className="h-24 w-auto object-contain" onError={handleBrandLogoError} />
          </div>
        ) : null}
        <header className="flex items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--card)] px-3 py-1 text-xs text-[var(--muted-foreground)] shadow-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-sky-500" />
              Cuestionario basado en neurociencia
            </div>
            <h1 className="mt-3 text-3xl font-bold text-[var(--foreground)]">Descubre tu futuro profesional</h1>
            <p className="mt-1 text-sm text-[var(--muted-foreground)]">
              Paso {step} de {totalSteps} · Orientación personalizada
            </p>
          </div>
          <ProgressRing value={progress} />
        </header>

        <section className="mt-8 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-6 shadow-sm">
          {error && (
            <div className="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
          )}

          {step === STEP_PRE && (
            <div className="grid gap-5">
              <div>
                <h2 className="text-lg font-semibold text-[var(--foreground)]">Bienvenido/a</h2>
                <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                  Completa {questions.length} preguntas para obtener tu perfil de talentos y orientación profesional personalizada.
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>Nombre</Label>
                  <Input value={pre.nombre} onChange={(e) => updatePre("nombre", e.target.value)} placeholder="Nombre" />
                </div>
                <div>
                  <Label>Correo</Label>
                  <Input
                    value={pre.email}
                    onChange={(e) => updatePre("email", e.target.value)}
                    placeholder="correo@ejemplo.com"
                    type="email"
                    inputMode="email"
                  />
                </div>
              </div>

              <div className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-4">
                <h3 className="text-sm font-semibold text-[var(--foreground)]">Cómo funciona</h3>
                <ul className="mt-2 space-y-1 text-sm text-[var(--muted-foreground)]">
                  <li>• {questions.length} afirmaciones presentadas de forma aleatoria</li>
                  <li>• Responde de 0 a 3 según tu forma habitual de ser</li>
                  <li>• No hay respuestas correctas o incorrectas</li>
                  <li>• Las preguntas no revelan a qué talento corresponden</li>
                </ul>
              </div>
            </div>
          )}

          {isQuestionStep && currentQ && currentQ.text && (
            <>
              <div className="flex items-baseline justify-between gap-4">
                <h2 className="text-lg font-semibold text-[var(--foreground)]">
                  Pregunta {safeNum(qIndex + 1)} de {questions.length}
                </h2>
                <div className="text-xs text-[var(--muted-foreground)]">0–3</div>
              </div>

              <div className="mt-5 rounded-3xl border border-[var(--border)] bg-[var(--background)] p-6">
                <div className="space-y-2">
                  <div className="text-sm font-semibold text-[var(--muted-foreground)]">{STEM}</div>
                  <div className="text-xl font-semibold leading-snug text-[var(--foreground)]">
                    {normalizeItemText(currentQ.text)}
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {SCALE.map(({ n, label }) => {
                    const active = answers[currentQ.itemId] === n;
                    return (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setAnswer(currentQ.itemId, n)}
                        className={cx(
                          "rounded-2xl px-4 py-3 text-left transition border",
                          active
                            ? "bg-[var(--foreground)] text-[var(--background)] border-[var(--foreground)] shadow-[0_14px_30px_-18px_rgba(0,0,0,0.35)]"
                            : "bg-[var(--card)] border-[var(--border)] text-[var(--foreground)] hover:-translate-y-[1px] hover:opacity-95"
                        )}
                      >
                        <div className="text-sm font-semibold">{n}</div>
                        <div className={cx("text-xs", active ? "text-[var(--background)]/80" : "text-[var(--muted-foreground)]")}>
                          {label}
                        </div>
                      </button>
                    );
                  })}
                </div>

                <p className="mt-4 text-xs text-[var(--muted-foreground)]">
                  Responde según tu forma habitual de ser. No hay respuestas correctas o incorrectas.
                </p>
              </div>
            </>
          )}

          {step === STEP_POST_1 && (
            <div className="grid gap-5">
              <div>
                <h2 className="text-lg font-semibold text-[var(--foreground)]">Datos académicos</h2>
                <p className="mt-1 text-sm text-[var(--muted-foreground)]">Completa la información para finalizar.</p>
              </div>

              <div>
                <Label>Apellidos</Label>
                <Input value={post.apellido} onChange={(e) => updatePost("apellido", e.target.value)} placeholder="Apellidos" />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>Fecha de nacimiento</Label>
                  <Input type="date" value={post.fechaNacimiento} onChange={(e) => updatePost("fechaNacimiento", e.target.value)} />
                </div>
                <div>
                  <Label>Sexo</Label>
                  <Select value={post.genero} onChange={(e) => updatePost("genero", e.target.value as PostData["genero"])}>
                    <option value="">Selecciona…</option>
                    <option value="Femenino">Femenino</option>
                    <option value="Masculino">Masculino</option>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>Curso</Label>
                  <Input value={post.curso} onChange={(e) => updatePost("curso", e.target.value)} placeholder="Ej: 1º Bachillerato" />
                </div>
                <div>
                  <Label>Modalidad</Label>
                  <Input
                    value={post.modalidad}
                    onChange={(e) => updatePost("modalidad", e.target.value)}
                    placeholder="Ej: Ciencias / Letras / FP…"
                  />
                </div>
              </div>

              <div>
                <Label>{isSanCristobal ? "Centro educativo" : "Centro educativo (opcional)"}</Label>
                <Input
                  value={isSanCristobal ? SANCRISTOBAL_CENTER : post.centroEducativo}
                  onChange={(e) => updatePost("centroEducativo", e.target.value)}
                  placeholder="IES / Colegio / Universidad…"
                  disabled={isSanCristobal}
                />
              </div>
            </div>
          )}

          {step === STEP_POST_2 && (
            <div className="grid gap-5">
              <div>
                <h2 className="text-lg font-semibold text-[var(--foreground)]">Preferencias</h2>
                <p className="mt-1 text-sm text-[var(--muted-foreground)]">Sobre tu idea de carrera.</p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>¿Tienes una idea de carrera?</Label>
                  <Select
                    value={post.ideaCarreraFinal}
                    onChange={(e) => updatePost("ideaCarreraFinal", e.target.value as PostData["ideaCarreraFinal"])}
                  >
                    <option value="">Selecciona…</option>
                    <option value="Sí">Sí</option>
                    <option value="No">No</option>
                  </Select>
                </div>

                <div>
                  <Label>¿Cuál?</Label>
                  <Input
                    value={post.ideaCarreraTextoFinal}
                    onChange={(e) => updatePost("ideaCarreraTextoFinal", e.target.value)}
                    placeholder="Ej: Medicina, Informática, Diseño…"
                    disabled={post.ideaCarreraFinal !== "Sí"}
                  />
                </div>
              </div>
            </div>
          )}

          {step === STEP_POST_3 &&
            (() => {
              const top3 = ranked.slice(0, 3);
              const allCareers = top3
                .filter((t) => Array.isArray(t.exampleRoles) && t.exampleRoles.length > 0)
                .flatMap((t) =>
                  t.exampleRoles.filter((role): role is string => typeof role === "string" && role.trim().length > 0)
                );
              const suggestedCareers = Array.from(new Set(allCareers));

              return (
                <div className="grid gap-5">
                  <div>
                    <h2 className="text-lg font-semibold text-[var(--foreground)]">De tus resultados, encajas en estos campos profesionales</h2>
                    <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                      Basado en tus talentos principales. Selecciona con cuáles te identificas (obligatorio):
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {suggestedCareers.map((career) => (
                      <button
                        key={career}
                        onClick={() => toggleCareer(career)}
                        className={cx(
                          "w-full p-3 rounded-lg border-2 text-left transition-all",
                          selectedCareers.includes(career)
                            ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
                            : "border-[var(--border)] bg-[var(--card)] hover:border-[var(--muted-foreground)]"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={cx(
                              "w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0",
                              selectedCareers.includes(career)
                                ? "border-[var(--background)] bg-[var(--background)]"
                                : "border-[var(--muted-foreground)]"
                            )}
                          >
                            {selectedCareers.includes(career) && (
                              <svg className="w-3 h-3 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                          <span className="text-sm">{career}</span>
                        </div>
                      </button>
                    ))}

                    <button
                      onClick={() => toggleCareer("Otro")}
                      className={cx(
                        "w-full p-3 rounded-lg border-2 text-left transition-all",
                        selectedCareers.includes("Otro")
                          ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
                          : "border-[var(--border)] bg-[var(--card)] hover:border-[var(--muted-foreground)]"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={cx(
                            "w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0",
                            selectedCareers.includes("Otro")
                              ? "border-[var(--background)] bg-[var(--background)]"
                              : "border-[var(--muted-foreground)]"
                          )}
                        >
                          {selectedCareers.includes("Otro") && (
                            <svg className="w-3 h-3 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                        <span className="text-sm font-semibold">Otro</span>
                      </div>
                    </button>
                  </div>

                  {selectedCareers.includes("Otro") && (
                    <div className="mt-2">
                      <input
                        type="text"
                        value={otroCareerText}
                        onChange={(e) => setOtroCareerText(e.target.value)}
                        placeholder="Escribe tu campo profesional..."
                        className="w-full p-3 rounded-lg border-2 border-[var(--border)] bg-[var(--card)] text-sm text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] focus:outline-none focus:border-[var(--foreground)] transition-colors"
                      />
                    </div>
                  )}

                  <div className="mt-2">
                    <button
                      onClick={() => toggleCareer("Ninguna")}
                      className={cx(
                        "w-full p-3 rounded-lg border-2 text-left transition-all",
                        selectedCareers.includes("Ninguna")
                          ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
                          : "border-[var(--border)] bg-[var(--card)] hover:border-[var(--muted-foreground)]"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={cx(
                            "w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0",
                            selectedCareers.includes("Ninguna")
                              ? "border-[var(--background)] bg-[var(--background)]"
                              : "border-[var(--muted-foreground)]"
                          )}
                        >
                          {selectedCareers.includes("Ninguna") && (
                            <svg className="w-3 h-3 text-[var(--foreground)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                        <span className="text-sm font-semibold">Ninguna</span>
                      </div>
                    </button>
                  </div>

                  {selectedCareers.length > 0 && !selectedCareers.includes("Ninguna") && (
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <p className="text-sm text-green-800">✓ Has seleccionado {selectedCareers.length} opción(es)</p>
                    </div>
                  )}

                  <div className="pt-2">
                    <ButtonPrimary type="button" onClick={saveAll} disabled={saving} className="w-full">
                      {saving ? "Guardando…" : "Guardar y finalizar"}
                    </ButtonPrimary>
                  </div>
                </div>
              );
            })()}

          {step === STEP_DONE && (
            <div className="grid gap-4">
              <h2 className="text-lg font-semibold text-[var(--foreground)]">Registro completado</h2>
              <p className="text-sm text-[var(--muted-foreground)]">Gracias. Tus respuestas han quedado registradas correctamente.</p>
            </div>
          )}

          {step !== STEP_DONE && step !== STEP_RESULT && (
            <div className="mt-6 flex items-center justify-between gap-3">
              <ButtonGhost type="button" onClick={back} disabled={step === STEP_PRE || saving}>
                Atrás
              </ButtonGhost>

              {step < STEP_Q_END ? (
                <ButtonPrimary type="button" onClick={next}>
                  Siguiente
                </ButtonPrimary>
              ) : step === STEP_Q_END ? (
                <ButtonPrimary type="button" onClick={next}>
                  Ver resultado
                </ButtonPrimary>
              ) : step === STEP_POST_1 || step === STEP_POST_2 ? (
                <ButtonPrimary type="button" onClick={next} disabled={saving}>
                  Siguiente
                </ButtonPrimary>
              ) : (
                <div />
              )}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
