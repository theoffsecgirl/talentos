export type TalentItem = {
  id: string;
  text: string;
};

export type Talent = {
  id: number;
  code: string;

  // NO se usa en preguntas (para informe)
  titleSymbolic: string;
  titleGenotype: string;

  // Este es el que usa el cuestionario
  quizTitle: string;

  intro: string;
  items: TalentItem[];

  // Contenido para informe (del PDF adaptado a neurociencia)
  reportTitle?: string;
  reportSummary?: string;
  axis?: string; // Eje neurocognitivo: PRAGMÁTICO / GENERADOR / VÍNCULO
  group?: string; // Agrupación secundaria: ACCIÓN Y RESULTADOS, CREATIVIDAD Y VÍNCULO, PROFUNDIDAD Y SENSIBILIDAD
  fields?: string[]; // Campos profesionales
  competencies?: string[]; // Competencias personales
  exampleRoles?: string[]; // Profesiones
};

export const TALENTS: Talent[] = [
  {
    id: 1,
    code: "DELTA",
    titleSymbolic: "Delta (Δ) — Estrategia y comunicación",
    titleGenotype: "Triángulo",
    quizTitle: "Estrategia y comunicación",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "1.1", text: "Me importa especialmente que estén bien remuneradas." },
      { id: "1.2", text: "Puedo expresarme con soltura y hablar en público con seguridad." },
      { id: "1.3", text: "Disfruto convenciendo, negociando, persuadiendo o vendiendo ideas." },
      { id: "1.4", text: "Me motiva liderar equipos para lograr resultados y reconocimiento." },
      { id: "1.5", text: "Me veo trabajando en ámbitos como ventas, marketing, publicidad o gestión de marcas." },
    ],

    axis: "GENERADOR",
    group: "CREATIVIDAD Y VÍNCULO",
    reportTitle: "Estrategia y comunicación",
    reportSummary:
      "Perfil con facilidad por la estrategia y el arte de la palabra y la oratoria. También tienen capacidad para vender, convencer y negociar. Es el talento de las personas que realizan su actividad profesional sustentada en la habilidad comunicativa, la capacidad comercial y negociadora, y la perseverancia para alcanzar los objetivos propuestos. Propio de personas divulgadoras, políticas que trasladan una imagen de éxito de sí mismas.",
    fields: [
      "Gestión empresarial, principalmente comercial",
      "Divulgación y comunicación",
      "Negociación",
      "Conexión con personas",
    ],
    competencies: [
      "Crean utilizando todo tipo de estrategias para conseguir sus objetivos",
      "Dominan la comunicación, la oratoria y el arte de la palabra",
      "Son especialistas en inteligencia emocional y dominan las claves",
      "Lideran desde su habilidad comunicativa y generando conexión",
    ],
    exampleRoles: [
      "Todas las del mundo de la venta y la negociación",
      "Marketing, comunicación audiovisual",
      "Técnicos en imagen o sonido, director-realizador de medios audiovisuales",
      "Relaciones laborales, ciencias del trabajo",
      "Política, derecho, diplomacia, divulgación técnica, periodismo",
    ],
  },
  {
    id: 2,
    code: "PI",
    titleSymbolic: "Pi (Π) — Investigación y ciencia aplicada",
    titleGenotype: "Pentágono",
    quizTitle: "Investigación y ciencia aplicada",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "2.1", text: "Puedo dedicarme a la ciencia, la investigación o el descubrimiento de cosas nuevas." },
      { id: "2.2", text: "Me gusta comprobar, validar o refutar hipótesis y teorías." },
      { id: "2.3", text: "Prefiero basarme en la razón y el pensamiento lógico más que en la emoción." },
      { id: "2.4", text: "Siento curiosidad por entender el porqué de las cosas que me interesan." },
      { id: "2.5", text: "Disfruto desarrollando y profundizando mis conocimientos intelectuales." },
    ],

    axis: "PRAGMÁTICO",
    group: "ACCIÓN Y RESULTADOS",
    reportTitle: "Investigación y ciencia aplicada",
    reportSummary:
      "Perfil que muestra interés por la investigación y pasión por el descubrimiento. Es habitual que generen ideas innovadoras. Les atrae el mundo de la ciencia por su curiosidad intelectual aplicada a todos los ámbitos profesionales. Es el talento de las personas que realizan su actividad profesional sustentada en altos conocimientos, la aplicación de lo que se sabe y la búsqueda de lo que se quiere saber.",
    fields: [
      "Investigación científica",
      "La salud: humana, animal, de la naturaleza",
      "Ciencias aplicadas",
      "Tecnología y diseño del entorno",
    ],
    competencies: [
      "Crean desde una base de conocimiento, estudian y exploran lo imposible",
      "Se comunican con un lenguaje culto y técnico",
      "Conocen la inteligencia emocional, pero no les preocupa su aplicación",
      "Lideran desde el saber, la autoridad científica",
    ],
    exampleRoles: [
      "Todas las profesiones que requieran un buen nivel de conocimientos, curiosidad científica y deseo de saber",
      "Geología, biología, astronomía, química, ciencias ambientales, ciencias del deporte, física",
      "Medicina, fisioterapia, odontología, dietética, oftalmología, medicina especialista (cardiología, pediatría, etc.)",
      "Ingenierías: telecomunicación, aeronáutica, electrónica, informática",
      "T.S. desarrollo aplicaciones informáticas, administración de sistemas informáticos, especialista en telemática",
    ],
  },
  {
    id: 3,
    code: "PSI",
    titleSymbolic: "Psi (Ψ) — Acompañamiento y facilitación",
    titleGenotype: "Infinito",
    quizTitle: "Acompañamiento y facilitación",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "3.1", text: "Puedo fomentar el aprendizaje, la convivencia y el autoconocimiento." },
      { id: "3.2", text: "Siento una curiosidad constante por aprender y comprender más." },
      { id: "3.3", text: "Me gusta acompañar a otras personas para que desarrollen su mejor versión." },
      { id: "3.4", text: "Destaco por escuchar, comprender y empatizar con los demás." },
      { id: "3.5", text: "Me interesa ayudar al desarrollo emocional de personas y equipos." },
    ],

    axis: "GENERADOR",
    group: "CREATIVIDAD Y VÍNCULO",
    reportTitle: "Acompañamiento y facilitación",
    reportSummary:
      "Perfil interesado por el saber y el conocimiento. Suele ser personas expresivas y comunicativas, con capacidad de escucha y de visión crítica. Es el talento de las personas que realizan su actividad profesional sustentada en el acompañamiento de otras personas para hacerlas crecer y conseguir lo mejor de sí mismas. Propio de todo tipo de gestores de personas, docentes y formadores, filósofos, psicólogos y personas que realizan diferentes tipos de terapias.",
    fields: [
      "Humanidades",
      "Docencia, coaching, RRHH",
      "Salud, desarrollo y crecimiento de las personas",
    ],
    competencies: [
      "Crean utilizando todo tipo de pensamiento, divergente o disruptivo",
      "Dominan la comunicación y la oratoria para convencer y enseñar",
      "Son especialistas en inteligencia emocional, empáticos y asertivos",
      "Lideran desde el comportamiento y son un ejemplo enriquecedor",
    ],
    exampleRoles: [
      "Docencia, pedagogía, sociología, educación social",
      "Técnicos en educación de todas las etapas educativas, educación especial, docencia vocacional",
      "Psicología y técnicos especializados en el acompañamiento de personas para mejorar su bienestar, coaching",
      "Área de personas de las organizaciones: selección, contratación, reclutamiento, planes de carrera, salud corporativa",
    ],
  },
  {
    id: 4,
    code: "ALFA",
    titleSymbolic: "Alfa (Α) — Control y gestión",
    titleGenotype: "Cuadrado",
    quizTitle: "Control y gestión",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "4.1", text: "Puedo gestionar y administrar recursos económicos, humanos o técnicos." },
      { id: "4.2", text: "Me encaja que todo tenga una lógica clara y una explicación racional." },
      { id: "4.3", text: "Me motiva alcanzar objetivos, tener éxito y emprender proyectos propios." },
      { id: "4.4", text: "Me veo formando parte de cuerpos de seguridad o estructuras muy organizadas." },
      { id: "4.5", text: "Estoy dispuesto a asumir responsabilidades y liderar equipos o situaciones complejas." },
    ],

    axis: "PRAGMÁTICO",
    group: "ACCIÓN Y RESULTADOS",
    reportTitle: "Control y gestión",
    reportSummary:
      "Perfil que muestra capacidad de control, gestión y organización, también, para seguir, proponer y dirigir retos. Pueden ser emprendedores y muestran iniciativas para conseguir éxitos y resultados. Es el talento de las personas que realizan su actividad profesional sustentada en la capacidad de gestionar recursos de todo tipo y donde el análisis y la razón están por delante de la emoción. Se automotivan, tienen las ideas muy claras y saben cuáles son sus objetivos, que siempre controlan y nunca dejan de focalizar.",
    fields: [
      "Empresarial",
      "Administrativo",
      "Financiero",
      "Legal",
      "Seguridad y protección",
    ],
    competencies: [
      "Crean desde una base analítica o de conocimiento previo, no imaginan",
      "Se comunican de forma directa, breve, van al grano",
      "Conocen la inteligencia emocional, pero la razón va por delante de la emoción",
      "Lideran desde la jerarquía, les cuesta delegar y pueden ser inflexibles",
    ],
    exampleRoles: [
      "Economía, ciencias actuariales y financieras, abogacía",
      "Administración de recursos y personas",
      "Agentes de la propiedad inmobiliaria, gestión administrativa",
      "Emprendimiento, iniciativa empresarial. Saben conseguir que los objetivos se cumplan. Solucionan los problemas cuando se presentan",
      "Cuerpos de seguridad del Estado, principalmente con responsabilidades y nivel de mando",
    ],
  },
  {
    id: 5,
    code: "OMEGA",
    titleSymbolic: "Omega (Ω) — Trascendencia y intuición",
    titleGenotype: "Círculo",
    quizTitle: "Trascendencia y intuición",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "5.1", text: "Siento que ayudo directamente a otras personas." },
      { id: "5.2", text: "Puedo mejorar el bienestar y la calidad de vida de los demás." },
      { id: "5.3", text: "Me interesa contribuir al bien común y a la resolución de conflictos." },
      { id: "5.4", text: "Actúo desde la intuición, el compromiso y el altruismo." },
      { id: "5.5", text: "Me motiva la idea de transformar el mundo y hacerlo más justo y digno." },
    ],

    axis: "VÍNCULO",
    group: "PROFUNDIDAD Y SENSIBILIDAD",
    reportTitle: "Trascendencia y intuición",
    reportSummary:
      "Perfil que prioriza el bienestar de las personas, ayudar es una prioridad. Se caracterizan por su intuición y también por su compromiso y altruismo. Capacidad para comprender los sentimientos y resolver conflictos. Es el talento de las personas que realizan su actividad profesional proyectada en la entrega, y la ayuda incondicional a los demás. Las diferentes actividades que se emprenden a nivel profesional deben tener una trascendencia en el ser humano, la ecología, el bienestar colectivo, la mejora de las condiciones de vida de las personas. Propio de profesionales relacionados con salud física y mental, educación, trabajos humanitarios, o servicios sociales.",
    fields: [
      "Relacionados con las personas y la entrega personal y profesional",
    ],
    competencies: [
      "Crean visualizando un mundo mejor, más justo y equitativo",
      "Comunican estableciendo enlaces potentes",
      "Son especialistas en inteligencia emocional, sobre todo intrapersonal",
      "Lideran siendo un referente, sabiendo escuchar, con el ejemplo",
    ],
    exampleRoles: [
      "Pedagogía, psicología escolar, educadores y trabajadores sociales y todo lo que signifique acompañar y ayudar a niños y niñas en su crecimiento y evolución madurativa",
      "Medicina centrada en la persona y su recuperación, especialistas en pediatría, psiquiatría, etc.",
      "Personas especializadas en servicios sociales y salud, entidades sin ánimo de lucro",
      "Entrega personal y profesional de forma vocacional",
    ],
  },
  {
    id: 6,
    code: "FI",
    titleSymbolic: "Fi (Φ) — Creatividad e inventiva",
    titleGenotype: "Elipse",
    quizTitle: "Creatividad e inventiva",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "6.1", text: "Me interesa la práctica deportiva de élite profesional." },
      { id: "6.2", text: "Puedo vivir de una creatividad práctica, innovadora y en constante cambio." },
      { id: "6.3", text: "Expreso mi sensibilidad a través del arte, la imaginación o lo visual." },
      { id: "6.4", text: "Me gusta formar parte de equipos creativos con retos estimulantes." },
      { id: "6.5", text: "Valoro que cada día sea diferente y poco predecible." },
    ],

    axis: "GENERADOR",
    group: "CREATIVIDAD Y VÍNCULO",
    reportTitle: "Creatividad e inventiva",
    reportSummary:
      "Perfil que se caracteriza por su pasión por la creatividad y suelen destacar por su gran imaginación e inventiva, aplicada a todos los ámbitos profesionales. Puede expresarse en las diferentes modalidades de arte, ya sean las más tradicionales, como el cine, el teatro, la pintura o la música, pero también pueden asociarse a todo tipo de ciencias aplicadas como la arquitectura, ingenierías, o incluso del mundo de la salud donde sea necesaria la creatividad para solucionar todo tipo de problemas. Finalmente también pueden incluirse las diferentes habilidades deportivas que pueden proporcionar una actividad profesional de élite.",
    fields: [
      "Capacidades artísticas",
      "Creatividad aplicada a todos los ámbitos profesionales y personales",
      "Arte en todas sus expresiones",
      "Deporte de élite",
    ],
    competencies: [
      "Crean constantemente en todas las facetas de la vida",
      "Comunican desde el entusiasmo cuando visualizan oportunidades",
      "Viven la emoción pero no siempre son comprendidos en las ideas",
      "Lideran desde el contagio para conseguir nuevos objetivos",
    ],
    exampleRoles: [
      "Creatividad aplicada a la actividad profesional: arquitectura, ingenierías, venta, política, RRHH, medicina, etc.",
      "Ideas sin límite para innovar y solucionar todo tipo de problemas",
      "Habilidades deportivas y artísticas en todas las expresiones",
      "Deportes de élite: fútbol, baloncesto, gimnasia, tiro con arco, atletismo, natación, etc.",
    ],
  },
  {
    id: 7,
    code: "THETA",
    titleSymbolic: "Theta (Θ) — Introspección y mirada interior",
    titleGenotype: "Rombo",
    quizTitle: "Introspección y mirada interior",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "7.1", text: "Se requiere un pensamiento profundo, analítico y reflexivo." },
      { id: "7.2", text: "Se tratan temas difíciles como el dolor, el trauma, la enfermedad o la muerte." },
      { id: "7.3", text: "Puedo investigar fraudes, engaños o comportamientos ocultos." },
      { id: "7.4", text: "Me atrae explorar lo oculto, el misterio, el crimen o lo no evidente." },
      { id: "7.5", text: "Me interesa el arte neogótico, la estética dark, el gore o expresiones artísticas alternativas." },
    ],

    axis: "VÍNCULO",
    group: "PROFUNDIDAD Y SENSIBILIDAD",
    reportTitle: "Introspección y mirada interior",
    reportSummary:
      "Perfil que muestra sensibilidad y profundidad en la manera de percibir el mundo, tanto personal como profesional. Suelen sentir atracción por temas ocultos o no evidentes y que requieren introspección, intuición, investigación y profundidad: la muerte, acontecimientos traumáticos, la diversidad mental y conductual. Suelen tener atracción por temas duros de la vida, como los cercanos a la muerte, el dolor, o el trauma. Propio de profesionales que acompañan en final de la vida, como cuidados paliativos, tanatopraxia, enfermedades mentales severas, oncológicas, etc. También de investigación criminal, forense, o psiquiátrica. Pueden dedicarse a actividades artísticas, como el cine, literatura, pintura, diseño de moda, etc, relacionadas con la oscuridad, el terror, el misterio, o el crimen.",
    fields: [
      "Sanitario",
      "Jurídico-social",
      "Investigación del fraude, el error, la estafa",
      "Artístico del mundo cute-gore, neo-gore, gothic, coming-of-age",
    ],
    competencies: [
      "Crean en zonas ocultas, profundas, a veces de difícil comprensión",
      "Su comunicación es especial, necesita un nivel de conocimiento diferente",
      "Viven las emociones de una forma diferente y no son muy sociables",
      "Lideran desde la generación de estilos que cautivan a seguidores",
    ],
    exampleRoles: [
      "Todos los ámbitos profesionales donde sea necesaria una sensibilidad especial para detectar lo que no es evidente, requiere investigar, intuir, descubrir",
      "Salud en psiquiatría, psicología, oncología, forense, y técnicos especializados en el mundo de la muerte o el trauma",
      "Criminología, y técnicos especializados en la investigación y el descubrimiento de lo oculto",
      "Investigación en el mundo de la empresa: forensic, actuarial, fraudes, inspecciones, etc.",
      "Arte alternativo, diseño dark, tatuajes, body art, expresiones artísticas no convencionales",
    ],
  },
  {
    id: 8,
    code: "MEANDRO",
    titleSymbolic: "Meandro (▭) — Funcionalidad y cooperación",
    titleGenotype: "Rectángulo",
    quizTitle: "Funcionalidad y cooperación",
    intro: "Me atraen actividades o profesiones en las que…",
    items: [
      { id: "8.1", text: "Sigo normas, ejecuto planes y llevo las ideas a la práctica." },
      { id: "8.2", text: "Valoro la estabilidad, la previsibilidad y el cumplimiento de responsabilidades." },
      { id: "8.3", text: "Trabajo bien siguiendo instrucciones claras para alcanzar objetivos concretos." },
      { id: "8.4", text: "Me gusta facilitar la vida de otras personas cumpliendo expectativas." },
      { id: "8.5", text: "Destaco por mi constancia, estabilidad y capacidad de servicio." },
    ],

    axis: "PRAGMÁTICO",
    group: "ACCIÓN Y RESULTADOS",
    reportTitle: "Funcionalidad y cooperación",
    reportSummary:
      "Perfil que demuestra facilidad de adaptación al trabajo rutinario, así como constancia y responsabilidad para cumplir retos y objetivos con una alta capacidad funcional y de proyección hacia el equipo de trabajo. Es el talento de las personas que realizan su actividad profesional siguiendo las instrucciones que reciben de un organismo superior. Cumplen, son responsables y logran los objetivos que les han sido encomendados. Propio de todo tipo de trabajo que se ejecuta con precisión, responsabilidad y alta cooperación con el equipo.",
    fields: [
      "Administración",
      "Educación",
      "Agrario",
    ],
    competencies: [
      "La creatividad no es su característica principal",
      "Se comunican de forma clara y sin florituras",
      "No son expertos en inteligencia emocional, pero no generan conflicto",
      "Lideran desde el hacer, son un modelo y ejemplo de cumplimiento",
    ],
    exampleRoles: [
      "Educación básica, funcionariado, trabajos que impliquen seguridad, repetición, compromiso y responsabilidad",
      "Técnicos en gestión administrativa y comercial",
      "Técnicos en trabajos forestales y conservación del medio ambiente",
      "Mantenimiento de instalaciones y transporte",
      "Técnicos en turismo y restauración, tripulante de cabina o auxiliar de barco",
      "Fuerzas de seguridad del estado y la vigilancia",
    ],
  },
];

// Configuración de ejes neurocognitivos
export const AXES = {
  ACCION_RESULTADOS: {
    name: "Acción y resultados",
    shortName: "Acción y resultados",
    description: "Incluye los talentos vinculados a la organización, la estrategia, la toma de decisiones y la orientación al logro.",
    talents: [4, 1],
  },
  IMAGINACION_ARTE: {
    name: "Imaginación y arte",
    shortName: "Imaginación y arte",
    description: "Agrupa los talentos relacionados con la creatividad, la expresión, la intuición y la mirada interior.",
    talents: [6, 7],
  },
  DESTREZA_PROYECCION: {
    name: "Destreza y proyección",
    shortName: "Destreza y proyección",
    description: "Recoge los talentos orientados a la ejecución, la cooperación, la trascendencia y la proyección hacia los demás.",
    talents: [8, 5],
  },
  SABER_CONOCIMIENTO: {
    name: "Saber y conocimiento",
    shortName: "Saber y conocimiento",
    description: "Reúne los talentos asociados a la investigación, el aprendizaje, la facilitación y la transmisión del conocimiento.",
    talents: [2, 3],
  },
};

// Función helper para generar indicador visual de puntuación
export function scoreIndicator(score: number, max: number): string {
  if (max === 0) return "0 de 0";
  const normalized = Math.round((score / max) * 5); // Escala a /5 para visual
  return `${normalized} de 5`;
}
